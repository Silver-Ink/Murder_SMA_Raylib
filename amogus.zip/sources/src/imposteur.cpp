#include "to_include.hpp"


void Imposteur::findNextDest()
{
	// a redéfinir
}

