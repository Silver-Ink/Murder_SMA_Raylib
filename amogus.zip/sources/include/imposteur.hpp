#ifndef DEF_IMPOSTEUR
#define DEF_IMPOSTEUR
#include "to_include.hpp"

class Imposteur : public Amogus{
	virtual void findNextDest();
};

#endif